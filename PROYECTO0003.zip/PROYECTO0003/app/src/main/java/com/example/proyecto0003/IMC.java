package com.example.proyecto0003;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class IMC extends AppCompatActivity {

    private TextView app, peso, estatura, resultado;
    private ImageView logo;
    private EditText valorKilos, valormetros, resultadoimc;
    private CheckBox femenino, masculino;
    private Button imc, pesoideal, borrar;
    double pi = 0, piup = 0, pidown = 0, f1 = 2.25, f2 = 45, m1 = 2.7, m2 = 47.75;
    boolean bandera = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc02);

        app = (TextView) findViewById(R.id.tvTitulo);
        peso = (TextView) findViewById(R.id.peso);
        estatura = (TextView) findViewById(R.id.estatura);
        resultado = (TextView) findViewById(R.id.tvResulta);
        logo = (ImageView) findViewById(R.id.logo);
        valorKilos = (EditText) findViewById(R.id.pesovalor);
        valormetros = (EditText) findViewById(R.id.estaturavalor);
        resultadoimc = (EditText) findViewById(R.id.etResulta);
        femenino = (CheckBox) findViewById(R.id.fem);
        masculino = (CheckBox) findViewById(R.id.mas);
        imc = (Button) findViewById(R.id.buttonimc);
        pesoideal = (Button) findViewById(R.id.buttonideal);

    }

    public void imc(View view){
        if (valorKilos.getText().toString().trim().length() == 0) {
            valorKilos.requestFocus();

            Toast.makeText(this, "Favor de ingresar el peso.", Toast.LENGTH_LONG).show();

        } else if (valormetros.getText().toString().trim().length() == 0){
            valormetros.requestFocus();

            Toast.makeText(this, "Favor de ingresar la estatura.", Toast.LENGTH_LONG).show();
        }else{

            float Kg = Float.parseFloat(valorKilos.getText().toString());
            float m = Float.parseFloat(valormetros.getText().toString());
            float bmi = (Kg / (m * m));

            if (bmi < 18.0) {
                Toast.makeText(this, "Tu imc es:" + bmi + "\n" + "Bajo peso", Toast.LENGTH_SHORT).show();
                resultadoimc.setText(String.valueOf((bmi)));
            }else {
                if (bmi < 24.9){
                    Toast.makeText(this, "Tu imc es:" + bmi + "\n" + "Peso normal", Toast.LENGTH_SHORT).show();
                    resultadoimc.setText(String.valueOf((bmi)));
                }else {
                    if (bmi < 29.9){
                        Toast.makeText(this, "Tu imc es:" + bmi + "\n" + "Sobre peso", Toast.LENGTH_SHORT).show();
                        resultadoimc.setText(String.valueOf((bmi)));
                    }else{
                        if (bmi < 34.9) {
                            Toast.makeText(this, "Tu imc es:" + bmi + "\n" + "Obecidad", Toast.LENGTH_SHORT).show();
                            resultadoimc.setText(String.valueOf((bmi)));

                        }else{
                            if (bmi > 35){
                                Toast.makeText(this, "Tu imc es:" + bmi + "\n" + "Muy obeso", Toast.LENGTH_SHORT).show();
                                resultadoimc.setText(String.valueOf((bmi)));
                            }
                        }
                    }
                }
            }
        }
    }

    public void borrar(View view){
        valorKilos.setText("");
        valorKilos.requestFocus();
        valormetros.setText("");
        resultadoimc.setText("");
        pi = 0;
        piup = 0;
        pidown = 0;
        femenino.setEnabled(true);
        masculino.setEnabled(true);
        femenino.setChecked(false);
        masculino.setChecked(false);
        bandera=true;

    }

    public void pesoideal (View view){

        float Kg = Float.parseFloat(valorKilos.getText().toString());
        float m = Float.parseFloat(valormetros.getText().toString());

        if(valorKilos.getText().toString().trim().length() == 0){
            valorKilos.requestFocus();

            Toast.makeText(this, "Favor de ingresar el peso.", Toast.LENGTH_SHORT).show();
            bandera = false;

        }else if (valormetros.getText().toString().trim().length() ==0){
            valormetros.requestFocus();

            Toast.makeText(this, "Favor de ingresar la estaatura.", Toast.LENGTH_SHORT).show();
            bandera = false;

        }else if (masculino.isChecked() == false && femenino.isChecked() == false){
            Toast.makeText(this, "Favor de seleccionar un genero.", Toast.LENGTH_SHORT).show();
            bandera = false;


        }
        if(femenino.isChecked() == true){

            masculino.setEnabled(false);
            pi = ((((100 * m) - 152.4) / 2.54) * f1) +f2;

        }else if (masculino.isChecked() == true){

            femenino.setEnabled(false);
            pi = ((((100 * m) - 152.4) / 2.54) * m1) +m2;

        }
        if (bandera){
            piup = (pi * 0.10) + pi;
            Toast.makeText(this, "Resultado del peso ideal " + pi + "\n", Toast.LENGTH_SHORT).show();
            resultadoimc.setText(String.valueOf((pi)));
            pidown = (pi - (pi * 0.10));

            if (Kg > piup){
                Toast.makeText(this, "Estas arriba de tu peso ideal", Toast.LENGTH_SHORT).show();
            }else if (Kg <= piup && Kg >= pidown){

                Toast.makeText(this, "Estas en tu peso ideal", Toast.LENGTH_SHORT).show();
            }else if (Kg < pidown){

                Toast.makeText(this, "Estas abajo de tu peso ideal", Toast.LENGTH_SHORT).show();
            }

        }

    }

    public void onCheckboxClickedfem(View view){

        femenino.setChecked(true);
        masculino.setChecked(false);
        Toast.makeText(this, "Femenino.", Toast.LENGTH_SHORT).show();
    }

    public void onCheckboxClickedmas (View view){

        masculino.setChecked(true);
        femenino.setChecked(false);
        Toast.makeText(this, "Masculino", Toast.LENGTH_SHORT).show();
    }
}

