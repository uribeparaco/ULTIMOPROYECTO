package com.example.proyecto0003;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class T_corporal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tcorporal);

        final EditText editTextTemperature = findViewById(R.id.editTextTemperature);
        final Button btnDiagnose = findViewById(R.id.btnDiagnose);
        final TextView textViewDiagnosis = findViewById(R.id.textViewDiagnosis);

        btnDiagnose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener la temperatura como cadena
                String temperatureStr = editTextTemperature.getText().toString();

                // Verificar si la cadena no está vacía
                if (!temperatureStr.isEmpty()) {
                    // Convertir la cadena a número
                    int temperature = Integer.parseInt(temperatureStr);

                    // Obtener el diagnóstico según la temperatura
                    String diagnosis = getDiagnosis(temperature);

                    // Mostrar el diagnóstico
                    textViewDiagnosis.setText("Diagnóstico: " + diagnosis);
                } else {
                    textViewDiagnosis.setText("Por favor, ingrese la temperatura.");
                }
            }
        });
    }

    private String getDiagnosis(int temperature) {
        if (temperature < 35) {
            return "Temperatura baja";
        } else if (temperature <= 37) {
            return "Fiebre normal";
        } else  {
            return "Fiebre alta";
        }
    }
}