package com.example.proyecto0003;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Temperatura extends AppCompatActivity {

    private boolean isFahrenheit = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperatura);

        EditText editTextTemperature = findViewById(R.id.editTextTemperature);
        Button buttonConvert = findViewById(R.id.buttonConvert);
        Button buttonToggle = findViewById(R.id.buttonToggle);
        TextView textViewResult = findViewById(R.id.textViewResult);

        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temperatureStr = editTextTemperature.getText().toString();
                if (!temperatureStr.isEmpty()) {
                    double temperature = Double.parseDouble(temperatureStr);
                    if (isFahrenheit) {
                        // Convertir Fahrenheit a Celsius
                        double celsius = (temperature - 32) * 5/9;
                        textViewResult.setText(String.format("%.2f °C", celsius));
                    } else {
                        // Convertir Celsius a Fahrenheit
                        double fahrenheit = (temperature * 9/5) + 32;
                        textViewResult.setText(String.format("%.2f °F", fahrenheit));
                    }
                } else {
                    textViewResult.setText("Ingrese una temperatura");
                }
            }
        });

        buttonToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isFahrenheit = !isFahrenheit;
                String buttonText = isFahrenheit ? "Cambiar a Celsius" : "Cambiar a Fahrenheit";
                buttonToggle.setText(buttonText);
                textViewResult.setText(""); // Limpiar el resultado al cambiar la unidad
            }
        });
    }
}
